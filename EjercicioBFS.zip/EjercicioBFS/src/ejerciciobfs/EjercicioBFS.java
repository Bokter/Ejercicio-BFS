/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciobfs;

import java.util.ArrayList;

/**
 *
 * @author augustosalazar
 */
public class EjercicioBFS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Grafo g = new Grafo();
        
        Vertice E = new Vertice("E");
        Vertice A = new Vertice("A");
        Vertice B = new Vertice("B");
        Vertice C = new Vertice("C");
        Vertice D = new Vertice("D");
        Vertice F = new Vertice("F");
        Vertice X = new Vertice("X");
        
        g.addVertice(E); // 0
        g.addVertice(A); // 1
        g.addVertice(B); // 2
        g.addVertice(C); // 3
        g.addVertice(D); // 4
        g.addVertice(F); // 5
        g.addVertice(X); // 6
        
        g.connectVertices(E,A);
        g.connectVertices(E,B);
        g.connectVertices(E,C);
        g.connectVertices(A,D);
        g.connectVertices(B,C);
        g.connectVertices(B,F);
        g.connectVertices(F,D);
        g.connectVertices(D,X);
        
        //g.print();
        
        int inicio = 0;
        int fin = 6;
        
        ArrayList<Integer> BFS = g.BFS(inicio, fin);
     
        
        if(!BFS.isEmpty()){
            System.out.println("La ruta mas corta entre el nodo de inicio "+inicio
                    +" y el nodo "+fin
                    +" del fin es: ");
            System.out.println(BFS);
        } 
    }
    
}
