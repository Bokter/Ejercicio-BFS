/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciobfs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author rojasdelahoz
 */
public class Grafo {

    private ArrayList<Vertice> listaAdyacencia;
    private int[][] matrizAdyacencia;

    public Grafo() {
        this.listaAdyacencia = new ArrayList<>();
    }

    public void addVertice(Vertice v) {
        this.listaAdyacencia.add(v);
    }

    public void connectVertices(Vertice v1, Vertice v2) {

        if (this.matrizAdyacencia == null) {
            this.matrizAdyacencia = new int[listaAdyacencia.size()][listaAdyacencia.size()];
        }

        v1.agregarAdyacente(v2);
        v2.agregarAdyacente(v1);

        this.matrizAdyacencia[v1.getId()][v2.getId()] = 1;
        this.matrizAdyacencia[v2.getId()][v1.getId()] = 1;

    }
    // PC1 con PC2 y PC5, PC3 con PC4, PC5 con PC4 y PC2

    public void print() {

        // Lista
        System.out.println("Lista de adyacencia: ");
        for (Vertice v : listaAdyacencia) {
            System.out.println(" | " + v);
        }

        System.out.println("");

        // Matriz
        System.out.println("");

        for (int i = 0; i < matrizAdyacencia.length; i++) {
            for (int j = 0; j < matrizAdyacencia.length; j++) {
                System.out.print(" | " + matrizAdyacencia[i][j]);
            }
            System.out.println("");
        }

    }

    public ArrayList<Integer> BFS(int i, int f) {

        Queue<Integer> queue = new LinkedList<>();
        boolean[] visitados = new boolean[listaAdyacencia.size()];
        ArrayList<Integer> rutas = new ArrayList<>();
        int[] padre = new int[listaAdyacencia.size()];
        int a = -1;

        queue.offer(i);
        visitados[i] = true;
        padre[i] = -1;

        while (!queue.isEmpty()) {
            int actual = queue.poll();
            System.out.print(actual + " ");

            if (actual == f) {
                a = f;
                
                while (a != -1) {
                    rutas.add(a);
                    a = padre[a];
                }
                Collections.reverse(rutas);
                return rutas;
            }

            for (int j = 0; j < listaAdyacencia.size(); j++) {
                if (matrizAdyacencia[actual][j] == 1 && !visitados[j]) {
                    queue.offer(j);
                    visitados[j] = true;
                    padre[j] = actual;
                }
            }

        }
        return rutas;

    }

}
